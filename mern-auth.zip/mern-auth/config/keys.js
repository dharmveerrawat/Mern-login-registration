module.exports = {
  mongoURI: "mongodb+srv://admin:admin@user-w8y0g.mongodb.net/test?retryWrites=true&w=majority",
  secretOrKey: "secret"
};    